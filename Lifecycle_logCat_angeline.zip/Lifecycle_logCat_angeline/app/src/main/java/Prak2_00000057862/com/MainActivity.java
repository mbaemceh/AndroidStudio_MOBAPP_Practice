/*
Jawaban challenge nomor 1 :
activity lifecycle yang terjadi dikarenakan setiap aktifitas merespon terhadap transisi yang telah dibangin
sehingga ketika dijalankan maka siklus prosesnya akan mengikuti instruksi. Dalam activity ini digunakan instance
activity dan class activity yang merupakan callback satu sama lain.
 */

package Prak2_00000057862.com;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("posisi", "onCreate");

        Button tombol1 = (Button)findViewById(R.id.button1);
        tombol1.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Log.i("aksi","Tombol 1 diklik");
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("posisi", "onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("posisi", "onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("posisi", "onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        Log.i("posisi", "onStop");
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("posisi", "onRestart");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("posisi", "onDestroy");
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.i("posisi", "onSaveInstanceState");
    }
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.i("posisi", "onRestoreInstanceState");
    }
}